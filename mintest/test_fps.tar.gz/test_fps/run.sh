java -cp "target/lib/*":target/test_fps-0.0.1-SNAPSHOT.jar com.zetes.projects.bosa.testfps.Main
